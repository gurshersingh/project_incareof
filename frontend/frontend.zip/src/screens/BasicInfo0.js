
import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';


/*
  = async () => {
  try {
await React.fetch('localhost:2000/api/job-seeker/registration', {
  method: 'POST',
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
  email: 'john1@doe.com',
first_name: 'John1',
last_name: 'Doe1',
phone_number: '99597079051',
city: 'Hello World',
password: 'password'
  })
  });
} catch (e) {
  console.log(e);
}
};

*/


// make the GET request to fetch data from the URL then using promise function to handle response.

const BasicInfo = props => (


  <View >
    <View >
      <Text style={styles.loginText}>Basic Information</Text>
    </View>
    <View style={styles.inputView2}>
      <Text style={styles.inputText1}>Title/Prefix</Text>
      <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>

	<View style={styles.inputView2}>
      <Text style={styles.inputText1}>First Name</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>

    <View style={styles.inputView2}>
      <Text style={styles.inputText1}>Last Name</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>
    <View style={styles.inputView2}>
      <Text style={styles.inputText1}>Company(optional)</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>
    <View style={styles.inputView2}>
      <Text style={styles.inputText1}>Email</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>

	<View style={styles.inputView2}>
      <Text style={styles.inputText1}>Confirm Email</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>

	<View style={styles.inputView2}>
      <Text style={styles.inputText1}>Phone Number</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>


    <View style={styles.loginBtn1}>
      <TouchableOpacity onPress={this.dbCall}>
      <Text style={styles.nextBtnText}>Submit</Text>
      </TouchableOpacity>
      </View>
      <View style={styles.loginBtn}>
        <TouchableOpacity onPress={() => props.navigation.navigate('AddInfo')}>
          <Text style={styles.nextBtnText}>Next</Text>
        </TouchableOpacity>

  </View>
  </View>

);
const styles = StyleSheet.create({
  nextBtnText: {
    color: 'black',
    fontSize: 20
  },
  inputText: {
    height: 30,
    color: 'black',
    marginTop: -17,
    marginLeft: -50,

  },
  inputText1: {
    height: 30,
    color: 'black',
   marginTop: 50,
marginLeft: 40,
  },
  loginText: {
  color: 'black',
  fontSize: 30,
  marginTop: 20,
  //marginBottom: 100,
  marginLeft: 65,
},
inputView2: {
  marginBottom: -35,
  },
  firstnameText: {
  //flex: 1,
      flexDirection: 'row',
      width: '45%',
      backgroundColor: '#64358D',
      borderRadius: 25,
      height: 30,
      marginTop: -40,
      marginLeft: 160,
      marginBottom: 10,

      justifyContent: 'center',
      padding: 20,
  },

  loginBtn: {
    width: '20%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -50,
    //marginBottom: 100,
    marginLeft: 285,
  },
  loginBtn1: {
    width: '20%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 150,
    //marginBottom: 100,
    marginLeft: 85,
  },
});

export default BasicInfo;
