import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,

  //Image,
} from 'react-native';
import axios from 'axios';


export default class ImagePickerExample extends React.Component {
  state = {
    image: null,
  };

dbCall() {
    axios.post('http://192.168.1.199:2000/api/job-seeker/registration',
      { email: 'john@doe3232333.com',
        first_name: 'John',
        last_name: 'Doe',
        phone_number: '9959707905',
        city: 'Hello World',
        password: 'password'
      })
    .then((response) => {
      if (response.data.status) {
      console.log(response);
      }
    })
  .catch((error) => {  })

 }

render() {
//  const { image } = this.state;
  this.dbCall()
  return (

  <View >
    <View >
    <Text style={styles.loginText}>Additional Information</Text>
    </View>
    <View style={styles.inputView2}>
      <Text style={styles.inputText1}>City</Text>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>

  <View style={styles.inputView2}>
    <View style={styles.firstnameText}>

      <TextInput
        style={styles.inputText}
        placeholder=" "
        placeholderTextColor="black"
        //onChangeText={text => this.setState({ email: text })}
      />
    </View>
    </View>
    <View style={styles.loginBtn1}>
      <TouchableOpacity onPress={this.dbCall()}>
      <Text style={styles.nextBtnText}>Submit</Text>
      </TouchableOpacity>
      </View>
    <View style={styles.loginBtn}>
        <TouchableOpacity onPress={() => this.props.navigation.navigate('UploadPic')}>
          <Text style={styles.nextBtnText}>Next</Text>
        </TouchableOpacity>

  </View>
  </View>

  );
}
}
  const styles = StyleSheet.create({
  nextBtnText: {
    color: 'black',
    fontSize: 20
  },
  inputText: {
    height: 30,
    color: 'black',
    marginTop: -17,
    marginLeft: -50,

  },
  inputText1: {
    height: 30,
    color: 'black',
   marginTop: 50,
  marginLeft: 40,
  },
  loginText: {
  color: 'black',
  fontSize: 30,
  marginTop: 20,
  //marginBottom: 100,
  marginLeft: 50,
  },
  inputView2: {
  marginBottom: -35,
  },
  firstnameText: {
  //flex: 1,
      flexDirection: 'row',
      width: '45%',
      backgroundColor: '#64358D',
      borderRadius: 25,
      height: 30,
      marginTop: -40,
      marginLeft: 160,
      marginBottom: 10,

      justifyContent: 'center',
      padding: 20,
  },

  loginBtn: {
    width: '20%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 150,
    //marginBottom: 100,
    marginLeft: 285,
  },
  loginBtn1: {
    width: '20%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 150,
    //marginBottom: 100,
    marginLeft: 85,
  },
});
