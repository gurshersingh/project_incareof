import React from 'react';
import {
  StyleSheet,
  Text,
  View,
//  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';

const RegisterScreen = props => (

<View style={styles.container}>
<View style={styles.image}>
<Image source={require('../../assets/logo.png')} />
</View>


<View style={styles.loginBtn}>
    <TouchableOpacity onPress={() => props.navigation.navigate('Basic')}>
      <Text style={styles.loginText}>Employer</Text>
    </TouchableOpacity>
</View>
    <View style={styles.loginBtn}>
    <TouchableOpacity onPress={() => props.navigation.navigate('Basic0')}>
      <Text style={styles.loginText}>Job Seeker</Text>
    </TouchableOpacity>
</View>

</View>

);
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  text: {
    fontSize: 30
  },

  loginBtn: {
    width: '70%',
    backgroundColor: '#8fbc8f',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  loginText: {
    color: 'white',
  },

});

export default RegisterScreen;
