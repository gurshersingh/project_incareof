import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  //TextInput,
  TouchableOpacity,
  //Image,
} from 'react-native';

const Membership = props => (
  <View style={styles.container}>

  <View style={styles.loginBtn}>
      <TouchableOpacity onPress={() => props.navigation.navigate('')}>
        <Text style={styles.loginText}>Plan A</Text>
      </TouchableOpacity>
  </View>
      <View style={styles.loginBtn}>
      <TouchableOpacity onPress={() => props.navigation.navigate('')}>
        <Text style={styles.loginText}>Plan B</Text>
      </TouchableOpacity>
  </View>
  <View style={styles.loginBtn}>
  <TouchableOpacity onPress={() => props.navigation.navigate('')}>
    <Text style={styles.loginText}>Plan C</Text>
  </TouchableOpacity>
</View>

<View style={styles.loginBtnnxt}>
    <TouchableOpacity onPress={() => props.navigation.navigate('Payment1Page')}>
      <Text style={styles.nextBtnText}>Next</Text>
    </TouchableOpacity>

</View>

  </View>

  );
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#ffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },

    text: {
      fontSize: 30
    },

    loginBtn: {
      width: '70%',
      backgroundColor: '#8fbc8f',
      borderRadius: 25,
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 10,
      marginBottom: 10,
    },
    loginText: {
      color: 'white',
    },
    loginBtnnxt: {
      width: '20%',
      backgroundColor: '#fb5b5a',
      borderRadius: 25,
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 150,
      //marginBottom: 100,
      marginLeft: 285,
    },
    nextBtnText: {
      color: 'black',
      fontSize: 20
    },

  });
export default Membership;
