import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';

const HomeScreen = props => (

<View style={styles.container}>
<View style={styles.image}>
  <Image source={require('../../assets/logo.png')} />
</View>
    <View style={styles.inputView}>
    <TextInput
      style={styles.inputText}
      placeholder="Email"
      placeholderTextColor="white"
      //onChangeText={text => this.setState({ email: text })}
    />

    </View>
    <View style={styles.inputView}>
    <TextInput
     secureTextEntry
     style={styles.inputText}
     placeholder="Password"
     placeholderTextColor="white"
     //onChangeText={text => this.setState({ email: text })}
    />
    </View>
    <TouchableOpacity>
      <Text style={styles.forgot}>Forgot Password?</Text>
    </TouchableOpacity>
<View style={styles.loginBtn}>
    <TouchableOpacity onPress={() => props.navigation.navigate('Login')}>
      <Text style={styles.loginText}>LOGIN</Text>
    </TouchableOpacity>
</View>
    <View style={styles.loginBtnsignup}>
    <TouchableOpacity onPress={() => props.navigation.navigate('RegisterScr')}>
      <Text style={styles.loginTextsignup}>SIGN UP</Text>
    </TouchableOpacity>
</View>

</View>

);
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputView: {
    width: '70%',
    backgroundColor: '#64358D',
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: 'center',
    padding: 20,
  },
  text: {
    fontSize: 30
  },
  inputText: {
    height: 50,
    color: 'white',
  },
  forgot: {
    color: 'black',
    fontSize: 11,
  },
  loginBtn: {
    width: '70%',
    backgroundColor: '#8fbc8f',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: 'white',
  },
  loginBtnsignup: {
    width: '70%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  loginTextsignup: {
    color: 'white',
  },
});

export default HomeScreen;

/*
import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
/*import Main from './components/Main';
const HomeScreen = () => {
//export default class HomeScreen extends React.Component {
  state = {
    email: '',
    password: '',
  };
  render() {
    return (
      <View style={styles.container}> ;
        <Text style={styles.logo} />
        <View style={styles.image}>
          <Image source={require('../../assets/splash.png')} />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.inputText}
            placeholder="Email..."
            placeholderTextColor="white"
            onChangeText={text => this.setState({ email: text })}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            secureTextEntry
            style={styles.inputText}
            placeholder="Password..."
            placeholderTextColor="white"
            onChangeText={text => this.setState({ password: text })}
          />
        </View>
        <TouchableOpacity>
          <Text style={styles.forgot}>Forgot Password?</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.loginBtn}>
          <Text style={styles.loginText}>LOGIN</Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text style={styles.loginText}>Signup</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  /*logo: {
    fontWeight: 'bold',
    fontSize: 50,
    color: '#fb5b5a',
    marginBottom: 40,
  },
  image: {
    width: '90%',
    //backgroundColor: '#465881',
    borderRadius: 25,
    height: 200,
    marginTop: 0,
    //justifyContent: 'center',
    padding: 20,
  },
  inputView: {
    width: '70%',
    backgroundColor: '#64358D',
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: 'center',
    padding: 20,
  },
  inputText: {
    height: 50,
    color: 'white',
  },
  forgot: {
    color: 'black',
    fontSize: 11,
  },
  loginBtn: {
    width: '70%',
    backgroundColor: '#fb5b5a',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: 'white',
  },
});
export default HomeScreen;
*/
