import { createStackNavigator, createAppContainer } from 'react-navigation';
import HomeScreen from './src/screens/HomeScreen';
import LogIn from './src/screens/LogIn';
import BasicInfo from './src/screens/BasicInfo';
import BasicInfo0 from './src/screens/BasicInfo0';
import AdditionalInfo from './src/screens/AdditionalInfo';
import UploadPhoto from './src/screens/UploadPhoto';
import Membership from './src/screens/Membership';
//import Payment from './src/screens/Payment';
import Payment1 from './src/screens/Payment1';
import Confirmation from './src/screens/Confirmation';
import PostJob from './src/screens/PostJob';
import Photo from './src/screens/photo';
import Register from './src/screens/RegisterScreen';
//import './node_modules/bootstrap/dist/css/bootstrap.min.css';

const navigator = createStackNavigator(
  {
    Home: HomeScreen,
    Login: LogIn,
    Basic: BasicInfo,
    Basic0: BasicInfo0,
    AddInfo: AdditionalInfo,
    UploadPic: UploadPhoto,
    MembershipPage: Membership,
  //PaymentPage: Payment,
    Payment1Page: Payment1,
    ConfirmationPage: Confirmation,
    PostJobPage: PostJob,
    UploadPhoto: Photo,
    RegisterScr: Register
  },
  {
    initialRouteName: 'Home',
    defaultNavigationOptions: {
      title: 'Incareof'
    }
  }
);

export default createAppContainer(navigator);
